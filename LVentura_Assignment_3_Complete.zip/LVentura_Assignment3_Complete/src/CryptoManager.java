/*
 * Class: CMSC203 
 * Instructor:Khandan Vahabzadeh Monshi
 * Description: Write a Java program to encrypt and decrypt a phrase using two similar approaches, 
 * each insecure by modern standards.
 * Due: 10/16/2023
 * Platform/compiler: Eclipse/Java
 * I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Luis E. Ventura Perez
*/



/**
 * This is a utility class that encrypts and decrypts a phrase using two
 * different approaches. The first approach is called the Caesar Cipher and is a
 * simple �substitution cipher� where characters in a message are replaced by a
 * substitute character. The second approach, due to Giovan Battista Bellaso,
 * uses a key word, where each character in the word specifies the offset for
 * the corresponding character in the message, with the key word wrapping around
 * as needed.
 * 
 * @author Farnaz Eivazi
 * @version 7/16/2022
 */
public class CryptoManager {
	
	private static final char LOWER_RANGE = ' ';//64
	private static final char UPPER_RANGE = '_';//108
	private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;//44

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_RANGE and UPPER_RANGE characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean isStringInBounds (String plainText) {
		//throw new RuntimeException("method not implemented");
		
		//return a true or false value
		boolean isStringInBounds = true;
		//run through every character 
		for (int i = 0; i < plainText.length(); i++) {
			//save value of each character 
			char a = plainText.charAt(i);
			//check the range
			if (a < LOWER_RANGE || a > UPPER_RANGE) {
				//true if we are inside the range
				isStringInBounds = false;
			} 
		}	
		
		//return true or false
		return isStringInBounds;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String caesarEncryption(String plainText, int key) {
		char c;
		int a;
		String s ="";
		
		for(int i=0;i<plainText.length();i++) {
			c =plainText.charAt(i);
			a=c;
			if(a>95 || a< ' ') {
			return "The selected string is not in bounds, Try again.";
		}
			
		a=c+key;
		while(a>95) {
			a-=RANGE;
		}
		c=(char)a;
		s+=c;
		}
		
		return s;	
	}
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String bellasoEncryption (String plainText, String bellasoStr) {
		 
		// Extend the key word
       StringBuilder extendedKey = new StringBuilder();
       
       for (int i = 0; i < plainText.length(); i++) {
           extendedKey.append(bellasoStr.charAt(i % bellasoStr.length()));
       }

       // Apply Bellaso_encryption logic to each character
       StringBuilder encryptedText = new StringBuilder();
       
       for (int i = 0; i < plainText.length(); i++) {
    	   
           char plainChar = plainText.charAt(i);
           char keyChar = extendedKey.charAt(i);

           // Calculate the offset
           int offset = plainChar + keyChar;

           // Wrap the offset within the specified range
           while (offset > 95) {
           offset -= 64; // Wrapping
           }

           // Convert the offset back to a character
           encryptedText.append((char) offset);
       }

       return encryptedText.toString();
	}
	
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String caesarDecryption (String encryptedText, int key) {
		
		char c;
		int n;
		String s ="";
			
		for(int i=0;i<encryptedText.length();i++) {
			c =encryptedText.charAt(i);
			n=c;
			if(n>95 || n< ' ') {
				return "The selected string is not in bounds, Try again.";
			}
			n=c-key;
			while(n< ' ') {
			n+=RANGE;
		}
			c=(char)n;
			s+=c;
		}
		return s;
	}
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String bellasoDecryption(String encryptedText, String bellasoStr) {
		//throw new RuntimeException("method not implemented");
		
		StringBuilder extendedKey = new StringBuilder();
        for (int i = 0; i < encryptedText.length(); i++) {
            extendedKey.append(bellasoStr.charAt(i % bellasoStr.length()));
        }

        // Apply Bellaso decryption logic to each character
        StringBuilder decryptedText = new StringBuilder();
        for (int i = 0; i < encryptedText.length(); i++) {
            char encryptedChar = encryptedText.charAt(i);
            char keyChar = extendedKey.charAt(i);

            // Calculate the offset for decryption
            int offset = encryptedChar - keyChar;

            // Wrap the offset within the specified range
            while (offset < 32) {
                offset += 64; // Wrapping
            }

            // Convert the offset back to a character
            decryptedText.append((char) offset);
        }

        return decryptedText.toString();
	}
}
